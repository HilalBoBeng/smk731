'use client'

import { useState, useEffect, useRef } from "react"
import { getStudentByNisn } from "@/data/studentData"
import { motion, AnimatePresence } from "framer-motion"
import { LucideSearch, LucideCheck, LucideX, LucideLoader, LucideVolume2, LucideVolumeX } from "lucide-react"
import confetti from 'canvas-confetti'

export default function NisnForm() {
  const [nisn, setNisn] = useState<string>("")
  const [student, setStudent] = useState<any>(null)
  const [error, setError] = useState<string>("")
  const [hasSearched, setHasSearched] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [showNotes, setShowNotes] = useState<boolean>(false)
  const [playing, setPlaying] = useState<boolean>(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  // Set up audio element
  useEffect(() => {
    if (typeof window !== "undefined") {
      // Will be updated based on student status in handleSubmit
      audioRef.current = new Audio("")
      audioRef.current.loop = true
    }
    
    return () => {
      if (audioRef.current) {
        audioRef.current.pause()
        audioRef.current.src = ""
      }
    }
  }, [])
  
  const toggleAudio = () => {
    if (audioRef.current) {
      if (playing) {
        audioRef.current.pause()
      } else {
        audioRef.current.play()
      }
      setPlaying(!playing)
    }
  }
  
  const triggerConfetti = () => {
    const duration = 5 * 1000;
    const animationEnd = Date.now() + duration;
    const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

    function randomInRange(min: number, max: number) {
      return Math.random() * (max - min) + min;
    }

    const interval: ReturnType<typeof setInterval> = setInterval(() => {
      const timeLeft = animationEnd - Date.now();

      if (timeLeft <= 0) {
        return clearInterval(interval);
      }

      const particleCount = 50 * (timeLeft / duration);
      
      // Since particles fall down, start a bit higher than random
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
      });
      confetti({
        ...defaults,
        particleCount,
        origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
      });
    }, 250);
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setHasSearched(true)
    setError("")
    setStudent(null)
    setIsLoading(true)
    setShowNotes(false)

    if (!nisn.trim()) {
      setError("NISN tidak boleh kosong.")
      setIsLoading(false)
      return
    }

    try {
      // Simulate API call
      setTimeout(() => {
        try {
          const foundStudent = getStudentByNisn(nisn)
          if (foundStudent) {
            setStudent(foundStudent)
            
            if (audioRef.current) {
              // Set appropriate music based on status
              if (foundStudent.status === "Lulus") {
                audioRef.current.src = "http://a.top4top.io/m_34245kz1u1.mp3"
                audioRef.current.play()
                setPlaying(true)
                triggerConfetti()
              } else {
                audioRef.current.src = "https://l.top4top.io/m_3425sez521.mp3"
                audioRef.current.play()
                setPlaying(true)
              }
            }
            setShowNotes(true)
          } else {
            setError("Data tidak ditemukan. Periksa kembali NISN Anda.")
          }
        } catch (err) {
          console.error("Error finding student:", err)
          setError("Terjadi kesalahan. Silakan coba lagi.")
        } finally {
          setIsLoading(false)
        }
      }, 1200)
    } catch (err) {
      console.error("Error in form submission:", err)
      setError("Terjadi kesalahan. Silakan coba lagi.")
      setIsLoading(false)
    }
  }

  const formVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        type: "spring", 
        stiffness: 300, 
        damping: 24 
      } 
    }
  }
  
  const resultVariants = {
    hidden: { opacity: 0, y: 30, scale: 0.9 },
    visible: { 
      opacity: 1, 
      y: 0, 
      scale: 1,
      transition: { 
        type: "spring", 
        stiffness: 200,
        duration: 0.5
      } 
    },
    exit: { 
      opacity: 0, 
      y: -20, 
      scale: 0.95,
      transition: { duration: 0.2 } 
    }
  }

  const resetSearch = () => {
    setNisn('');
    setHasSearched(false);
    setStudent(null);
    setError('');
    setShowNotes(false);
    setPlaying(false);
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  return (
    <motion.div 
      className="w-full max-w-3xl mx-auto relative"
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: {
          opacity: 1,
          transition: { 
            when: "beforeChildren",
            staggerChildren: 0.2
          }
        }
      }}
    >
      {!hasSearched || (hasSearched && !student && !error) ? (
        <motion.div 
          className="mb-8"
          variants={formVariants}
        >
          <form 
            onSubmit={handleSubmit} 
            className="bg-card p-8 rounded-xl shadow-lg border border-border relative overflow-hidden"
          >
            <div className="absolute -top-12 -right-12 w-40 h-40 bg-accent bg-opacity-20 rounded-full blur-xl"></div>
            <div className="absolute -bottom-16 -left-16 w-48 h-48 bg-primary bg-opacity-5 rounded-full blur-xl"></div>
            
            <motion.h3 
              className="text-2xl font-bold text-center mb-6 text-primary"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              Cek Hasil Kelulusan Anda
            </motion.h3>
            
            <div className="mb-6">
              <label htmlFor="nisn" className="block text-base font-medium text-foreground mb-2">
                Masukkan NISN Anda:
              </label>
              <div className="relative">
                <input
                  type="text"
                  id="nisn"
                  value={nisn}
                  onChange={(e) => setNisn(e.target.value)}
                  className="w-full p-4 pl-12 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-base"
                  placeholder="Masukkan NISN Anda"
                  maxLength={10}
                />
                <LucideSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={18} />
              </div>
            </div>
            
            <motion.button
              type="submit"
              className="w-full py-4 px-6 bg-primary text-primary-foreground font-semibold rounded-lg text-base shadow-md flex items-center justify-center"
              whileHover={{ scale: 1.02, backgroundColor: "var(--accent)", color: "var(--accent-foreground)" }}
              whileTap={{ scale: 0.98 }}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <LucideLoader className="mr-2 animate-spin" size={18} />
                  Mencari Data...
                </>
              ) : (
                <>Lihat Hasil Kelulusan</>
              )}
            </motion.button>
          </form>
        </motion.div>
      ) : null}

      <AnimatePresence mode="wait">
        {hasSearched && !isLoading && (
          <motion.div 
            key={`result-${error ? 'error' : (student ? student.nisn : 'empty')}`}
            variants={resultVariants}
            initial="hidden"
            animate="visible"
            exit="exit"
            className="mb-8"
          >
            <div className="bg-card p-8 rounded-xl shadow-lg border border-border relative overflow-hidden">
              <motion.button
                onClick={resetSearch}
                className="absolute top-4 left-4 p-2 flex items-center justify-center rounded-lg bg-background hover:bg-primary hover:bg-opacity-10 transition-colors z-10"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <LucideSearch className="h-5 w-5 mr-1" />
                <span className="text-sm font-medium">Cari lagi</span>
              </motion.button>
              {error ? (
                <motion.div 
                  className="flex flex-col items-center justify-center p-6"
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: "spring", stiffness: 200 }}
                >
                  <div className="rounded-full bg-destructive bg-opacity-10 p-4 mb-4">
                    <LucideX className="text-destructive" size={32} />
                  </div>
                  <p className="text-xl font-medium text-destructive text-center">{error}</p>
                </motion.div>
              ) : student ? (
                <>
                  <button 
                    onClick={toggleAudio} 
                    className="fixed bottom-4 right-4 z-50 p-3 rounded-full bg-primary shadow-lg flex items-center justify-center hover:bg-opacity-90 transition-all"
                    aria-label={playing ? "Matikan musik" : "Putar musik"}
                  >
                    {playing ? 
                      <LucideVolumeX size={22} className="text-primary-foreground" /> : 
                      <LucideVolume2 size={22} className="text-primary-foreground" />
                    }
                  </button>
                  
                  <div className="absolute top-0 right-0 w-full h-full overflow-hidden">
                    {student.status === "Lulus" ? (
                      <motion.div 
                        className="absolute inset-0 z-0"
                        animate={{ 
                          background: [
                            "radial-gradient(circle, rgba(255,255,255,0) 30%, rgba(50,70,211,0.05) 70%)",
                            "radial-gradient(circle, rgba(255,255,255,0) 20%, rgba(50,70,211,0.08) 80%)",
                            "radial-gradient(circle, rgba(255,255,255,0) 30%, rgba(50,70,211,0.05) 70%)"
                          ]
                        }}
                        transition={{ 
                          repeat: Infinity,
                          duration: 5,
                          ease: "easeInOut"
                        }}
                      />
                    ) : (
                      <motion.div 
                        className="absolute inset-0 z-0"
                        animate={{ 
                          background: [
                            "radial-gradient(circle, rgba(255,255,255,0) 30%, rgba(220,38,38,0.03) 70%)",
                            "radial-gradient(circle, rgba(255,255,255,0) 20%, rgba(220,38,38,0.05) 80%)",
                            "radial-gradient(circle, rgba(255,255,255,0) 30%, rgba(220,38,38,0.03) 70%)"
                          ]
                        }}
                        transition={{ 
                          repeat: Infinity,
                          duration: 6,
                          ease: "easeInOut"
                        }}
                      />
                    )}
                  </div>
                  
                  <motion.div 
                    className="flex flex-col items-center justify-center py-8"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ duration: 0.5 }}
                  >
                    <motion.div 
                      className="rounded-full bg-primary bg-opacity-10 p-4 mb-2"
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", stiffness: 200, delay: 0.2 }}
                    >
                      <LucideCheck className="text-primary" size={32} />
                    </motion.div>
                    
                    {student.status === "Lulus" ? (
                      <motion.div 
                        className="flex flex-col items-center space-y-4"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        <h3 className="text-2xl font-bold text-center">Hasil Pencarian</h3>
                        
                        <motion.div
                          className="w-full flex flex-col items-center justify-center pt-6"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.3, duration: 0.5 }}
                        >
                          <motion.div 
                            className="flex flex-col items-center justify-center"
                          >
                            <motion.h2 
                              className="text-6xl md:text-7xl font-bold text-green-600 cursor-pointer"
                              initial={{ scale: 0.7, opacity: 0 }}
                              animate={{ 
                                scale: [0.7, 1.1, 1],
                                opacity: 1
                              }}
                              transition={{ 
                                type: "spring",
                                stiffness: 300,
                                damping: 15,
                                delay: 0.5
                              }}
                              onClick={triggerConfetti}
                              title="Klik untuk efek konfeti!"
                            >
                              LULUS
                            </motion.h2>
                            
                            <motion.div
                              className="max-w-md text-center mt-6"
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 1, duration: 0.8 }}
                            >
                              <motion.p 
                                className="text-lg text-primary font-medium italic"
                                animate={{ 
                                  scale: [1, 1.03, 1],
                                }}
                                transition={{ 
                                  repeat: Infinity,
                                  repeatType: "reverse",
                                  duration: 3
                                }}
                              >
                                "Kebanggaan kita yang terbesar adalah bukan tidak pernah gagal, tetapi bangkit kembali setiap kali kita jatuh."
                              </motion.p>
                              <motion.p className="text-sm text-muted-foreground mt-2">
                                — Selamat atas pencapaianmu! Ini bukan akhir, tetapi awal dari petualangan baru.
                              </motion.p>
                            </motion.div>
                          </motion.div>
                          
                        </motion.div>
                        
                        <motion.div 
                          className="mt-4 w-full max-w-md space-y-4 border-t border-border pt-6"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 1.2 }}
                        >
                          <div className="flex flex-col gap-3">
                            <div className="flex flex-col">
                              <div className="text-lg text-muted-foreground mb-1">Nama:</div>
                              <div className="text-xl md:text-2xl font-bold text-foreground">{student.name}</div>
                            </div>
                            
                            <div className="flex flex-col mt-2">
                              <div className="text-lg text-muted-foreground mb-1">No Peserta:</div>
                              <div className="text-xl md:text-2xl font-bold text-foreground">{student.participantNo}</div>
                            </div>
                          </div>
                        </motion.div>
                      </motion.div>
                    ) : (
                      <motion.div 
                        className="flex flex-col items-center space-y-4"
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                      >
                        <h3 className="text-2xl font-bold text-center">Hasil Pencarian</h3>
                        
                        <motion.div
                          className="w-full flex flex-col items-center justify-center pt-6"
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: 0.3, duration: 0.5 }}
                        >
                          <motion.div 
                            className="flex flex-col items-center justify-center"
                          >
                            <motion.h2 
                              className="text-6xl md:text-7xl font-bold text-red-600"
                              initial={{ scale: 0.7, opacity: 0 }}
                              animate={{ 
                                scale: [0.7, 1.1, 1],
                                opacity: 1
                              }}
                              transition={{ 
                                type: "spring",
                                stiffness: 300,
                                damping: 15,
                                delay: 0.5
                              }}
                            >
                              {student.status}
                            </motion.h2>
                            
                            <motion.div
                              className="max-w-md text-center mt-6"
                              initial={{ opacity: 0, y: 20 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 1, duration: 0.8 }}
                            >
                              <motion.p 
                                className="text-lg text-primary font-medium italic"
                                animate={{ 
                                  scale: [1, 1.03, 1],
                                }}
                                transition={{ 
                                  repeat: Infinity,
                                  repeatType: "reverse",
                                  duration: 3
                                }}
                              >
                                "Kegagalan hanya terjadi ketika kita menyerah. Teruslah berusaha, karena setiap usaha adalah langkah menuju keberhasilan."
                              </motion.p>
                              <motion.p className="text-sm text-muted-foreground mt-2">
                                Jangan berkecil hati. Ini hanya satu tahap dalam perjalanan hidupmu.
                              </motion.p>
                            </motion.div>
                          </motion.div>
                        </motion.div>
                        
                        <motion.div 
                          className="mt-4 w-full max-w-md space-y-4 border-t border-border pt-6"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ delay: 1.2 }}
                        >
                          <div className="flex flex-col gap-3">
                            <div className="flex flex-col">
                              <div className="text-lg text-muted-foreground mb-1">Nama:</div>
                              <div className="text-xl md:text-2xl font-bold text-foreground">{student.name}</div>
                            </div>
                            
                            <div className="flex flex-col mt-2">
                              <div className="text-lg text-muted-foreground mb-1">No Peserta:</div>
                              <div className="text-xl md:text-2xl font-bold text-foreground">{student.participantNo}</div>
                            </div>
                          </div>
                        </motion.div>
                      </motion.div>
                    )}
                  </motion.div>
                </>
              ) : null}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {showNotes && (
        <motion.div 
          variants={formVariants}
          className="bg-card p-8 rounded-xl shadow-lg border border-border relative"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <div className="absolute -top-10 -left-10 w-32 h-32 bg-accent bg-opacity-10 rounded-full blur-md"></div>
          <h3 className="text-xl font-bold mb-5 relative">📄 Catatan Penting:</h3>
          <ul className="list-disc pl-5 space-y-3 text-base text-foreground relative">
            <li>Bagi peserta didik yang membutuhkan Surat Keterangan Kelulusan, silakan menghadap ke Bagian Tata Usaha pada hari dan jam kerja.</li>
            <li>Harap menggunakan pakaian yang rapi dan sopan.</li>
            <li>Tidak diperkenankan menggunakan kaos oblong dan celana Levis.</li>
          </ul>
        </motion.div>
      )}
    </motion.div>
  )
}

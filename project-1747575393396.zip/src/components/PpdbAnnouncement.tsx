'use client'

import { useEffect, useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import CountdownTimer from "./CountdownTimer"
import PpdbForm from "./PpdbForm"
import { initializePpdbData } from "@/data/ppdbData"

export default function PpdbAnnouncement() {
  // Target date: July 7, 2025, 08:30 WITA (GMT+8)
  const targetDate = new Date('2025-07-07T08:30:00+08:00')
  const [isTimeUp, setIsTimeUp] = useState<boolean>(false)
  
  useEffect(() => {
    // Initialize PPDB data in localStorage
    initializePpdbData()
    
    // Check if current time is past the target date
    const now = new Date()
    setIsTimeUp(now >= targetDate)
    
    // Set up an interval to check the time
    const interval = setInterval(() => {
      const currentTime = new Date()
      if (currentTime >= targetDate) {
        setIsTimeUp(true)
        clearInterval(interval)
      }
    }, 1000)
    
    return () => clearInterval(interval)
  }, [targetDate])
  
  return (
    <motion.div 
      className="w-full max-w-4xl mx-auto flex flex-col"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <motion.div 
        className="flex flex-col items-center mb-10"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 100, damping: 15, delay: 0.2 }}
      >
        <motion.div
          className="relative"
          animate={{ rotate: [0, 5, 0, -5, 0] }}
          transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
        >
          <motion.img 
            src="https://iili.io/36jtJuS.png" 
            alt="Logo SMK Kapal Karam 723 Tanah Soetji"
            className="w-32 h-auto mb-8 drop-shadow-lg animate-float" 
            whileHover={{ scale: 1.1, rotate: 5 }}
            transition={{ type: "spring", stiffness: 300 }}
          />
          <motion.div 
            className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 w-20 h-2 bg-black bg-opacity-10 rounded-full blur-md"
            animate={{ width: [16, 20, 16] }}
            transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
          />
        </motion.div>
        
        <motion.h1 
          className="text-3xl md:text-4xl font-bold text-center text-primary mb-4 relative"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <span>
            Pengumuman PPDB
          </span>
          <br />
          <span className="text-foreground">SMK Kapal Karam 723 Tanah Soetji</span>
        </motion.h1>
        
        <motion.h2 
          className="text-xl font-medium text-center text-muted-foreground mt-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
        >
          Tahun Ajaran 2025/2026
        </motion.h2>
      </motion.div>
      
      <AnimatePresence mode="wait">
        {isTimeUp ? (
          <motion.div
            key="form"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ type: "spring", stiffness: 100, damping: 15 }}
          >
            <PpdbForm />
          </motion.div>
        ) : (
          <motion.div
            key="countdown"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ type: "spring", stiffness: 100, damping: 15 }}
          >
            <CountdownTimer targetDate={targetDate} />
          </motion.div>
        )}
      </AnimatePresence>

    </motion.div>
  )
}

'use client'

import { useEffect, useState } from "react"
import dayjs from "dayjs"
import { motion } from "framer-motion"

interface CountdownProps {
  targetDate: Date
}

export default function CountdownTimer({ targetDate }: CountdownProps) {
  const [days, setDays] = useState<number>(0)
  const [hours, setHours] = useState<number>(0)
  const [minutes, setMinutes] = useState<number>(0)
  const [seconds, setSeconds] = useState<number>(0)
  const [isExpired, setIsExpired] = useState<boolean>(false)

  useEffect(() => {
    try {
      // Initialize with current values first
      const now = dayjs()
      const target = dayjs(targetDate)
      const diff = target.diff(now, 'second')
      
      if (diff <= 0) {
        setIsExpired(true)
        return
      }
      
      const d = Math.floor(diff / (24 * 60 * 60))
      const h = Math.floor((diff % (24 * 60 * 60)) / (60 * 60))
      const m = Math.floor((diff % (60 * 60)) / 60)
      const s = Math.floor(diff % 60)
      
      setDays(d)
      setHours(h)
      setMinutes(m)
      setSeconds(s)
      
      // Then set up the interval
      const interval = setInterval(() => {
        try {
          const currentNow = dayjs()
          const currentDiff = target.diff(currentNow, 'second')
          
          if (currentDiff <= 0) {
            setIsExpired(true)
            clearInterval(interval)
            return
          }
          
          const currentD = Math.floor(currentDiff / (24 * 60 * 60))
          const currentH = Math.floor((currentDiff % (24 * 60 * 60)) / (60 * 60))
          const currentM = Math.floor((currentDiff % (60 * 60)) / 60)
          const currentS = Math.floor(currentDiff % 60)
          
          setDays(currentD)
          setHours(currentH)
          setMinutes(currentM)
          setSeconds(currentS)
        } catch (err) {
          console.error("Error updating countdown:", err)
          clearInterval(interval)
        }
      }, 1000)
      
      return () => clearInterval(interval)
    } catch (err) {
      console.error("Error setting up countdown:", err)
    }
  }, [targetDate])

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2,
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { type: "spring", stiffness: 100 }
    }
  }

  const numberVariants = {
    initial: { scale: 0.8, opacity: 0.5 },
    animate: { scale: 1, opacity: 1 },
    transition: { type: "spring", stiffness: 200, damping: 10 }
  }

  return (
    <motion.div 
      className="w-full max-w-3xl mx-auto"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      <div className="text-center mb-12">
        <motion.h2 
          className="text-2xl md:text-3xl font-bold mb-8 text-primary"
          variants={itemVariants}
        >
          Pengumuman Akan Dibuka Dalam:
        </motion.h2>
        <motion.div 
          className="grid grid-cols-4 gap-6"
          variants={itemVariants}
        >
          <motion.div 
            className="bg-card border border-border rounded-xl p-6 shadow-lg relative overflow-hidden"
            whileHover={{ scale: 1.05, backgroundColor: "var(--accent)" }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary bg-opacity-10 rounded-full"></div>
            <motion.div 
              key={days} 
              className="text-5xl font-bold text-primary"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {days}
            </motion.div>
            <div className="text-sm font-medium text-muted-foreground mt-2">Hari</div>
          </motion.div>

          <motion.div 
            className="bg-card border border-border rounded-xl p-6 shadow-lg relative overflow-hidden"
            whileHover={{ scale: 1.05, backgroundColor: "var(--accent)" }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary bg-opacity-10 rounded-full"></div>
            <motion.div 
              key={hours} 
              className="text-5xl font-bold text-primary"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {hours}
            </motion.div>
            <div className="text-sm font-medium text-muted-foreground mt-2">Jam</div>
          </motion.div>

          <motion.div 
            className="bg-card border border-border rounded-xl p-6 shadow-lg relative overflow-hidden"
            whileHover={{ scale: 1.05, backgroundColor: "var(--accent)" }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary bg-opacity-10 rounded-full"></div>
            <motion.div 
              key={minutes} 
              className="text-5xl font-bold text-primary"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {minutes}
            </motion.div>
            <div className="text-sm font-medium text-muted-foreground mt-2">Menit</div>
          </motion.div>

          <motion.div 
            className="bg-card border border-border rounded-xl p-6 shadow-lg relative overflow-hidden"
            whileHover={{ scale: 1.05, backgroundColor: "var(--accent)" }}
            transition={{ type: "spring", stiffness: 300, damping: 20 }}
          >
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-primary bg-opacity-10 rounded-full"></div>
            <motion.div 
              key={seconds} 
              className="text-5xl font-bold text-primary"
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 200 }}
            >
              {seconds}
            </motion.div>
            <div className="text-sm font-medium text-muted-foreground mt-2">Detik</div>
          </motion.div>
        </motion.div>
      </div>
      
      <motion.div
        className="text-center text-muted-foreground mt-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
        <p className="text-lg">Harap bersabar untuk melihat hasil kelulusan Anda</p>
      </motion.div>
    </motion.div>
  )
}

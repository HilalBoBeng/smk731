// Student data structure
interface Student {
  participantNo: string;
  nisn: string;
  name: string;
  status: string;
}

// All student data
export const students: Student[] = [
  { participantNo: "12-029-001-8", nisn: "0006466462", name: "AHMAD FAQIH", status: "Lulus" },
  { participantNo: "12-029-002-7", nisn: "0012439322", name: "ARVELINO HERZANTIO", status: "Lulus" },
  { participantNo: "12-029-003-6", nisn: "0006693279", name: "FAHMI NURFAUZI", status: "Lulus" },
  { participantNo: "12-029-004-5", nisn: "0004061823", name: "FAJAR RIFKY FEBRIAN", status: "Lulus" },
  { participantNo: "12-029-005-4", nisn: "0006693786", name: "FARHAN DANAHISWARA", status: "Lulus" },
  { participantNo: "12-029-006-3", nisn: "0155700798", name: "HAPPY MELATI EMILANIA", status: "Lulus" },
  { participantNo: "12-029-007-2", nisn: "0006692780", name: "I GUSTI NGURAH AGUNG ARYA D.B.", status: "Lulus" },
  { participantNo: "12-029-008-9", nisn: "0009552343", name: "MUHAMMAD FAJRI ADI MULYA", status: "Lulus" },
  { participantNo: "12-029-009-8", nisn: "0006242295", name: "MUHAMMAD IQBAL MAJID", status: "Lulus" },
  { participantNo: "12-029-010-7", nisn: "0004694525", name: "NISRINA ZAKIYYAH ADISA", status: "Lulus" },
  { participantNo: "12-029-011-6", nisn: "0007307010", name: "PUTRI LEICA ZULKARNAIN", status: "Lulus" },
  { participantNo: "12-029-012-5", nisn: "0017673582", name: "RIZALDI RIZQI ASYRAF", status: "Lulus" },
  { participantNo: "12-029-013-4", nisn: "0003437272", name: "TRISNA AMARA MUKTI", status: "Lulus" },
  { participantNo: "12-029-014-3", nisn: "0009027440", name: "TUMPAL JONATHAN SITINJAK", status: "Lulus" },
  { participantNo: "12-029-015-2", nisn: "9990724425", name: "YUSUF MUMTAZUDIN", status: "Lulus" },
  { participantNo: "12-029-016-9", nisn: "0012439720", name: "DAFFA RADITYA WIBOWO", status: "Lulus" },
  { participantNo: "12-029-017-8", nisn: "0004181509", name: "KHALID AL-RAIF DESTIAWAN", status: "Lulus" },
  { participantNo: "12-029-018-7", nisn: "0003117594", name: "MARAYA ABISURYA PATANDIANAN", status: "Lulus" },
  { participantNo: "12-029-019-6", nisn: "0003114265", name: "MUHAMMAD WILDAN HELMI", status: "Lulus" },
  { participantNo: "12-029-020-5", nisn: "9995916025", name: "MUHAMMAD YAZIR RAMDHAN", status: "Lulus" },
  { participantNo: "12-029-021-4", nisn: "0003251179", name: "NOVI RAHMAWANTI", status: "Lulus" },
  { participantNo: "12-029-022-3", nisn: "0007071690", name: "TAZKIYA KHAIRUNISA", status: "Lulus" },
  { participantNo: "12-029-023-2", nisn: "0011312579", name: "AULIA HANIV", status: "Lulus" },
  { participantNo: "12-029-024-9", nisn: "0006693066", name: "GILANG DEVIALDY", status: "Lulus" },
  { participantNo: "12-029-025-8", nisn: "0001550901", name: "JUAN ALARIC SURYA", status: "Lulus" },
  { participantNo: "12-029-026-7", nisn: "0006422603", name: "MUHAMAD YUSRIL", status: "Lulus" },
  { participantNo: "12-029-027-6", nisn: "0007186094", name: "MUHAMMAD HAYKAL PRAMUDITO", status: "Lulus" },
  { participantNo: "12-029-028-5", nisn: "0003118463", name: "MUTIARA KARIMAH ANYAR", status: "Lulus" },
  { participantNo: "12-029-029-4", nisn: "0007448100", name: "NOVIA RAMADHANI", status: "Lulus" },
  { participantNo: "12-029-030-3", nisn: "0001290145", name: "RAFI RAMADHANI JIWANTO", status: "Lulus" },
  { participantNo: "12-029-031-2", nisn: "0000989038", name: "RENALDI CESARIO SITUMORANG", status: "Lulus" },
  { participantNo: "12-029-032-9", nisn: "0001848848", name: "RIFKY ANDHIKA MAULANA", status: "Lulus" },
  { participantNo: "12-029-033-8", nisn: "0007721819", name: "WAHYUDI JABBAR MUTTAQIN", status: "Lulus" },
  { participantNo: "12-029-034-7", nisn: "0004585824", name: "MOHAMMAD ADNAN ADITYA RACHMADI", status: "Lulus" },
  { participantNo: "12-029-035-6", nisn: "0002223715", name: "MOHAMMAD IVAN PRAKASA", status: "Lulus" },
  { participantNo: "12-029-036-5", nisn: "0004694555", name: "NAFIS WILDANI LUWIYANTO", status: "Lulus" },
  { participantNo: "12-029-037-4", nisn: "0005265275", name: "RIEFALDY NADIVKHA SUBROTO", status: "Lulus" },
  { participantNo: "12-029-038-3", nisn: "0018080339", name: "SULTHAN ARAFAT BRIFIAN", status: "Lulus" },
  { participantNo: "12-029-039-2", nisn: "0010202970", name: "SYUJA ASYRAF FARDHAN", status: "Lulus" },
  { participantNo: "12-029-040-9", nisn: "0003118315", name: "ADELA PUTRI HASTAMI", status: "Lulus" },
  { participantNo: "12-029-041-8", nisn: "0004737426", name: "DINDA AYU NINGSIH", status: "Lulus" },
  { participantNo: "12-029-041-8", nisn: "0004737424", name: "MAS AMBATUKAN AMBATIVASI AMBATRON SAYANG MAS RUSDI DI RODOK RODOK", status: "Tidak Lulus" },
];

// Function to get student by NISN
export function getStudentByNisn(nisn: string): Student | undefined {
  try {
    // First try to get from localStorage if we're in a browser
    if (typeof window !== "undefined") {
      const data = safeLocalStorage.getItem("studentData");
      if (data) {
        try {
          const storedStudents: Student[] = JSON.parse(data);
          const student = storedStudents.find(student => student.nisn === nisn);
          if (student) return student;
        } catch (e) {
          console.error("Error parsing student data:", e);
        }
      }
    }
  } catch (error) {
    console.error("Error in getStudentByNisn:", error);
  }
  
  // Fallback to the default data
  return students.find(student => student.nisn === nisn);
}

// Safely access localStorage with error handling
const safeLocalStorage = {
  getItem: (key: string): string | null => {
    if (typeof window === "undefined") return null;
    try {
      // Only access localStorage when window is defined
      const storage = typeof window !== "undefined" ? window.localStorage : null;
      return storage ? storage.getItem(key) : null;
    } catch (e) {
      console.error("Error reading from localStorage:", e);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    if (typeof window === "undefined") return;
    try {
      // Only access localStorage when window is defined
      const storage = typeof window !== "undefined" ? window.localStorage : null;
      if (storage) {
        storage.setItem(key, value);
      }
    } catch (e) {
      console.error("Error writing to localStorage:", e);
    }
  }
};

// Store student data in localStorage for persistence
export function initializeStudentData(): void {
  if (typeof window === "undefined") return;
  
  try {
    const existingData = safeLocalStorage.getItem("studentData");
    
    if (!existingData) {
      safeLocalStorage.setItem("studentData", JSON.stringify(students));
    }
  } catch (error) {
    console.error("Failed to initialize student data:", error);
  }
}

// Get students from localStorage
export function getStudentsFromStorage(): Student[] {
  const data = safeLocalStorage.getItem("studentData");
  if (data) {
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error("Error parsing student data:", e);
    }
  }
  return students;
}

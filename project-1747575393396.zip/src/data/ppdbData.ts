// PPDB Data structure
interface PpdbStudent {
  registrationNo: string;
  name: string;
  parentName: string;
  school: string;
  status: string;
  programChoice: string;
}

// All PPDB student data (sample data to be updated later)
export const ppdbStudents: PpdbStudent[] = [];

// Safely access localStorage with error handling
const safeLocalStorage = {
  getItem: (key: string): string | null => {
    if (typeof window === "undefined") return null;
    try {
      // Only access localStorage when window is defined
      const storage = typeof window !== "undefined" ? window.localStorage : null;
      return storage ? storage.getItem(key) : null;
    } catch (e) {
      console.error("Error reading from localStorage:", e);
      return null;
    }
  },
  setItem: (key: string, value: string): void => {
    if (typeof window === "undefined") return;
    try {
      // Only access localStorage when window is defined
      const storage = typeof window !== "undefined" ? window.localStorage : null;
      if (storage) {
        storage.setItem(key, value);
      }
    } catch (e) {
      console.error("Error writing to localStorage:", e);
    }
  }
};

// Store PPDB data in localStorage for persistence
export function initializePpdbData(): void {
  if (typeof window === "undefined") return;
  
  try {
    const existingData = safeLocalStorage.getItem("ppdbData");
    
    if (!existingData) {
      safeLocalStorage.setItem("ppdbData", JSON.stringify(ppdbStudents));
    }
  } catch (error) {
    console.error("Failed to initialize PPDB data:", error);
  }
}

// Function to get PPDB student by registration number
export function getStudentByRegistrationNo(registrationNo: string): PpdbStudent | undefined {
  try {
    // First try to get from localStorage if we're in a browser
    if (typeof window !== "undefined") {
      const data = safeLocalStorage.getItem("ppdbData");
      if (data) {
        try {
          const storedStudents: PpdbStudent[] = JSON.parse(data);
          const student = storedStudents.find(student => student.registrationNo === registrationNo);
          if (student) return student;
        } catch (e) {
          console.error("Error parsing PPDB data:", e);
        }
      }
    }
  } catch (error) {
    console.error("Error in getStudentByRegistrationNo:", error);
  }
  
  // Fallback to the default data
  return ppdbStudents.find(student => student.registrationNo === registrationNo);
}

// Get PPDB students from localStorage
export function getPpdbStudentsFromStorage(): PpdbStudent[] {
  const data = safeLocalStorage.getItem("ppdbData");
  if (data) {
    try {
      return JSON.parse(data);
    } catch (e) {
      console.error("Error parsing PPDB data:", e);
    }
  }
  return ppdbStudents;
}

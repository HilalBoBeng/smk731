'use client';

import { motion } from "framer-motion";
import Link from "next/link";
import { Users, GraduationCap, BookOpen, ArrowRight, School, Code, Clock, Heart, Bell } from "lucide-react";
export default function HomePage() {
  return <main className="min-h-screen flex flex-col">
      {/* Modern Header */}
      <div className="bg-white shadow-sm border-b border-gray-100 py-6">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <img src="https://iili.io/36jtJuS.png" alt="Logo SMK Kapal Karam 731" className="h-14 w-auto" />
              <div>
                <h1 className="text-2xl font-bold text-primary">SMK Kapal Karam 731</h1>
                <p className="text-sm text-gray-500">Tanah Soetji</p>
              </div>
            </div>
            
            <div className="hidden md:flex items-center space-x-6">
              <a href="#about" className="text-gray-600 hover:text-primary transition-colors">Tentang</a>
              <a href="#programs" className="text-gray-600 hover:text-primary transition-colors">Program</a>
              <a href="#portal" className="text-gray-600 hover:text-primary transition-colors">Portal</a>
              <a href="https://www.instagram.com/smkkapalkaram_723_tanahsoetji?igsh=MXJsZjhlNjFnZWptdA==" target="_blank" rel="noopener noreferrer" className="px-5 py-2 bg-primary text-white rounded-lg hover:bg-opacity-90 transition-all">
                Hubungi Kami
              </a>
            </div>
          </div>
        </div>
      </div>
      
      
      {/* Portal Services moved to top */}
      <section id="portal" className="py-10 px-6 bg-background">
        <div className="container mx-auto">
          <motion.div className="flex flex-col items-center justify-center gap-6" initial={{
          opacity: 0,
          y: 30
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.6
        }} viewport={{
          once: true
        }}>
            <h2 className="text-3xl font-bold text-center text-primary mb-6">Portal Layanan</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10 max-w-3xl w-full">
              <Link href="/pengumuman">
                <motion.div className="bg-white border-2 border-primary p-6 rounded-xl shadow-lg hover:shadow-xl transition-all flex flex-col items-center text-center cursor-pointer" whileHover={{
                y: -8,
                scale: 1.02
              }} whileTap={{
                scale: 0.98
              }}>
                  <div className="rounded-full bg-primary bg-opacity-10 p-4 mb-4">
                    <GraduationCap size={32} className="text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-primary">Pengumuman Kelulusan</h3>
                  <p className="text-muted-foreground">Cek status kelulusan taruna/i tahun ajaran 2024/2025</p>
                </motion.div>
              </Link>
              
              <Link href="/ppdb">
                <motion.div className="bg-white border-2 border-primary p-6 rounded-xl shadow-lg hover:shadow-xl transition-all flex flex-col items-center text-center cursor-pointer" whileHover={{
                y: -8,
                scale: 1.02
              }} whileTap={{
                scale: 0.98
              }}>
                  <div className="rounded-full bg-primary bg-opacity-10 p-4 mb-4">
                    <Users size={32} className="text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-primary">Portal PPDB</h3>
                  <p className="text-muted-foreground">Pendaftaran peserta didik baru tahun ajaran 2025/2026</p>
                </motion.div>
              </Link>
              
              <Link href="/pengumuman-ppdb">
                <motion.div className="bg-white border-2 border-primary p-6 rounded-xl shadow-lg hover:shadow-xl transition-all flex flex-col items-center text-center cursor-pointer md:col-span-2" whileHover={{
                y: -8,
                scale: 1.02
              }} whileTap={{
                scale: 0.98
              }}>
                  <div className="rounded-full bg-primary bg-opacity-10 p-4 mb-4">
                    <Bell size={32} className="text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2 text-primary">Pengumuman PPDB</h3>
                  <p className="text-muted-foreground">Cek hasil seleksi penerimaan taruna/i baru</p>
                </motion.div>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
      
      {/* About Section */}
      <section id="about" className="py-16 px-6 bg-background">
        <div className="container mx-auto">
          <motion.h2 className="text-3xl font-bold text-center text-primary mb-12" initial={{
          opacity: 0,
          y: -20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5
        }} viewport={{
          once: true
        }}>
            Tentang Sekolah Kami
          </motion.h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div initial={{
            opacity: 0,
            x: -30
          }} whileInView={{
            opacity: 1,
            x: 0
          }} transition={{
            duration: 0.6,
            delay: 0.2
          }} viewport={{
            once: true
          }}>
              <h3 className="text-2xl font-bold mb-4">Sejarah SMK Kapal Karam 723</h3>
              <p className="text-foreground mb-4">
                Didirikan pada tahun 1989, SMK Kapal Karam 723 Tanah Soetji telah menjadi lembaga pendidikan 
                terkemuka yang berfokus pada pengembangan keterampilan teknis dan pembentukan karakter. 
                Nama sekolah ini terinspirasi dari filosofi bahwa dari kesulitan dan tantangan, kita dapat 
                bangkit dan menemukan kekuatan sejati.
              </p>
              <p className="text-foreground mb-4">
                Selama lebih dari 30 tahun, sekolah kami telah mendidik ribuan taruna/i yang kini berhasil 
                dalam berbagai bidang, baik di kancah nasional maupun internasional. Kami bangga dengan 
                tradisi keunggulan akademis dan nilai-nilai luhur yang kami tanamkan pada setiap siswa.
              </p>
              <a href="https://www.instagram.com/smkkapalkaram_723_tanahsoetji?igsh=MXJsZjhlNjFnZWptdA==" target="_blank" rel="noopener noreferrer" className="text-primary font-medium flex items-center hover:underline">
                Lebih dekat dengan kami
                <ArrowRight size={16} className="ml-1" />
              </a>
            </motion.div>
            
            <motion.div className="relative h-[350px] rounded-xl overflow-hidden shadow-lg" initial={{
            opacity: 0,
            x: 30
          }} whileInView={{
            opacity: 1,
            x: 0
          }} transition={{
            duration: 0.6,
            delay: 0.3
          }} viewport={{
            once: true
          }}>
              <img 
                src="https://iili.io/36skwJe.png" 
                alt="SMK Kapal Karam 731 Building" 
                className="w-full h-full object-cover" 
              />
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Programs Section */}
      <section id="programs" className="py-16 px-6 bg-secondary">
        <div className="container mx-auto">
          <motion.h2 className="text-3xl font-bold text-center text-primary mb-4" initial={{
          opacity: 0,
          y: -20
        }} whileInView={{
          opacity: 1,
          y: 0
        }} transition={{
          duration: 0.5
        }} viewport={{
          once: true
        }}>
            Program Unggulan
          </motion.h2>
          
          <motion.p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto" initial={{
          opacity: 0
        }} whileInView={{
          opacity: 1
        }} transition={{
          duration: 0.5,
          delay: 0.2
        }} viewport={{
          once: true
        }}>
            Kami menawarkan berbagai program pendidikan yang dirancang untuk mengembangkan
            keterampilan dan bakat taruna/i dalam berbagai bidang.
          </motion.p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div className="bg-card p-8 rounded-xl shadow-md border border-border" initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.4,
            delay: 0.2
          }} viewport={{
            once: true
          }}>
              <div className="rounded-full bg-primary bg-opacity-10 p-4 w-fit mb-4">
                <School className="text-primary" size={28} />
              </div>
              <h3 className="text-xl font-bold mb-2">Rekayasa Kebersihan Otak dan Jiwa (RKOJ)</h3>
              <p className="text-muted-foreground">
                Bikin kamu bersih dari cinta palsu dan mantan toksik. Program unggulan dengan kurikulum
                terbaru untuk taruna/i modern.
              </p>
            </motion.div>
            
            <motion.div className="bg-card p-8 rounded-xl shadow-md border border-border" initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.4,
            delay: 0.3
          }} viewport={{
            once: true
          }}>
              <div className="rounded-full bg-primary bg-opacity-10 p-4 w-fit mb-4">
                <BookOpen className="text-primary" size={28} />
              </div>
              <h3 className="text-xl font-bold mb-2">Teknik Pendinginan Hati & Perasaan (TPHP)</h3>
              <p className="text-muted-foreground">
                Jurus anti baper, auto slow like es batu. Tenaga pengajar berpengalaman dan 
                bersertifikat siap membimbing taruna/i.
              </p>
            </motion.div>
            
            <motion.div className="bg-card p-8 rounded-xl shadow-md border border-border" initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.4,
            delay: 0.4
          }} viewport={{
            once: true
          }}>
              <div className="rounded-full bg-primary bg-opacity-10 p-4 w-fit mb-4">
                <Code className="text-primary" size={28} />
              </div>
              <h3 className="text-xl font-bold mb-2">Multimedia Kelas Dewa (MKD)</h3>
              <p className="text-muted-foreground">
                Editan api naga & tulisan "Sakit Tapi Tak Berdarah" level profesional. Kurikulum
                terkini dan relevan.
              </p>
            </motion.div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
            <motion.div className="bg-card p-8 rounded-xl shadow-md border border-border" initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.4,
            delay: 0.5
          }} viewport={{
            once: true
          }}>
              <div className="rounded-full bg-primary bg-opacity-10 p-4 w-fit mb-4">
                <Clock className="text-primary" size={28} />
              </div>
              <h3 className="text-xl font-bold mb-2">Teknik Mesin Waktu dan Penyesalan (TMWP)</h3>
              <p className="text-muted-foreground">
                Khusus buat yang ingin kembali ke masa lalu, tapi cuma bisa nyesel. Program unggulan
                dengan metode pembelajaran interaktif.
              </p>
            </motion.div>
            
            <motion.div className="bg-card p-8 rounded-xl shadow-md border border-border" initial={{
            opacity: 0,
            y: 30
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.4,
            delay: 0.6
          }} viewport={{
            once: true
          }}>
              <div className="rounded-full bg-primary bg-opacity-10 p-4 w-fit mb-4">
                <Heart className="text-primary" size={28} />
              </div>
              <h3 className="text-xl font-bold mb-2">PPLG (Pemrograman Perasaan Level Gacor)</h3>
              <p className="text-muted-foreground">
                Nge-code sambil ngatur perasaan? Di sini tempatnya, bosku! Program dengan teknologi
                terbaru dan paling update.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Portal section moved to the top */}
      
      <footer className="w-full py-6 text-center text-sm text-muted-foreground border-t border-border mt-auto">
        <p className="font-medium">© 2025 SMK Kapal Karam 723 Tanah Soetji</p>
        <p className="mt-1">Created by Tim IT Beng</p>
      </footer>
    </main>;
}

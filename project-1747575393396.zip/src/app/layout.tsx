import "@/styles/globals.css";
import React from "react";

import { Poppins, Inter } from 'next/font/google';

import { DevtoolsProvider } from 'creatr-devtools'
const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-poppins',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
});
import { type Metadata } from "next";

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export const metadata: Metadata = {
  title: {
    default: "SMK Kapal Karam 731 Tanah Soetji | Portal Web Resmi",
    template: "SMK Kapal Karam 731 Tanah Soetji | %s",
  },
  description: "Sistem Pengumuman Kelulusan SMK Kapal Karam 731 Tanah Soetji Tahun Ajaran 2024/2025",
  applicationName: "Sistem Pengumuman SMK Kapal Karam 731",
  keywords: ["kelulusan", "SMK Kapal Karam 731 Tanah Soetji", "pengumuman", "sekolah"],
  authors: [{ name: "Tim IT Beng" }],
  creator: "Tim IT Beng",
  publisher: "SMK Kapal Karam 723 Tanah Soetji",
  icons: {
    icon: [
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
      { url: "/favicon.ico", sizes: "48x48", type: "image/x-icon" },
    ],
    apple: [
      { url: "/apple-touch-icon.png", sizes: "180x180", type: "image/png" },
    ],
  },
  manifest: "/site.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Sistem Pengumuman Kelulusan",
  },
  formatDetection: {
    telephone: false,
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id" className={`${poppins.variable} ${inter.variable}`}>
      
  <body><DevtoolsProvider>{children}</DevtoolsProvider></body>

    </html>
  );
}

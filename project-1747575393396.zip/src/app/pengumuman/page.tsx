'use client'

import { motion } from "framer-motion"
import GraduationAnnouncement from "@/components/GraduationAnnouncement"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default function PengumumanPage() {
  return (
    <main className="min-h-screen py-16 px-6 flex flex-col justify-between items-center">
      <div className="container mx-auto flex-1 flex flex-col">
        <div className="mb-8 self-start">
          <Link href="/">
            <motion.button
              className="flex items-center gap-2 text-primary hover:text-primary-foreground hover:bg-primary px-4 py-2 rounded-lg transition-all"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <ArrowLeft size={18} />
              <span>Kembali ke Beranda</span>
            </motion.button>
          </Link>
        </div>
      
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex-1 flex flex-col justify-center"
        >
          <GraduationAnnouncement />
        </motion.div>
      </div>
      
      <footer className="w-full py-6 text-center text-sm text-muted-foreground border-t border-border mt-12">
        <p className="font-medium">© 2025 SMK Kapal Karam 723 Tanah Soetji</p>
        <p className="mt-1">Created by Tim IT Beng</p>
      </footer>
    </main>
  );
}

'use client'

import { useEffect, useState } from "react"
import { motion } from "framer-motion"
import { ArrowLeft, School, Users, Calendar, BookOpen, Book, Code, Award, Rocket, FileCheck, MessageCircle } from "lucide-react"
import Link from "next/link"

export default function PPDBPage() {
  const [isLoading, setIsLoading] = useState(true)
  
  useEffect(() => {
    // Simulate page loading
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 500)
    
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen bg-background">
      <header className="py-6 bg-background">
        <div className="container mx-auto px-6 flex flex-col items-center">
          <div className="mb-4 self-start w-full">
            <Link href="/" className="flex items-center gap-2 text-primary hover:text-primary-foreground hover:bg-primary px-4 py-2 rounded-lg transition-all w-fit">
              <ArrowLeft size={18} />
              <span>Kembali ke Beranda</span>
            </Link>
          </div>

          <motion.div 
            className="flex flex-col items-center mb-6"
            initial={{ y: -20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ type: "spring", stiffness: 100, damping: 15, delay: 0.2 }}
          >
            <motion.div
              className="relative"
              animate={{ rotate: [0, 5, 0, -5, 0] }}
              transition={{ repeat: Infinity, duration: 8, ease: "easeInOut" }}
            >
              <motion.img 
                src="https://iili.io/36jtJuS.png" 
                alt="Logo SMK Kapal Karam 723 Tanah Soetji"
                className="w-28 h-auto mb-6 drop-shadow-lg animate-float" 
                whileHover={{ scale: 1.1, rotate: 5 }}
                transition={{ type: "spring", stiffness: 300 }}
              />
              <motion.div 
                className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 w-16 h-1.5 bg-black bg-opacity-10 rounded-full blur-md"
                animate={{ width: [14, 16, 14] }}
                transition={{ repeat: Infinity, duration: 3, ease: "easeInOut" }}
              />
            </motion.div>
            
            <motion.h1 
              className="text-3xl font-bold text-center text-primary mb-2"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <span className="text-foreground">Pendaftaran PPDB</span>
              <br />
              <span>SMK Kapal Karam 723 Tanah Soetji</span>
            </motion.h1>
            
            <motion.h2 
              className="text-lg font-medium text-center text-muted-foreground"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              Tahun Ajaran 2025/2026
            </motion.h2>
          </motion.div>
        </div>
      </header>
      
      <main className="container mx-auto px-6 py-12">
        {isLoading ? (
          <div className="flex justify-center items-center h-96">
            <div className="animate-pulse-slow flex flex-col items-center">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-4 text-muted-foreground">Memuat informasi...</p>
            </div>
          </div>
        ) : (
          <>
            <section className="mb-16">
              <motion.div 
                className="flex flex-col items-center text-center mb-12"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-4xl font-bold text-primary mb-4">Portal PPDB</h2>
                <p className="text-xl text-muted-foreground max-w-2xl">
                  SMK Kapal Karam 723 Tanah Soetji membuka pendaftaran taruna/i baru untuk tahun ajaran 2025/2026.
                  Bergabunglah dengan kami untuk mendapatkan pendidikan berkualitas.
                </p>
              </motion.div>
              
              <motion.div 
                className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3, staggerChildren: 0.1 }}
              >
                <motion.div 
                  className="bg-card p-8 rounded-xl shadow-md border border-border relative overflow-hidden"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary bg-opacity-5 rounded-bl-full"></div>
                  <School size={48} className="text-primary mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Rekayasa Kebersihan Otak dan Jiwa (RKOJ)</h3>
                  <p className="text-muted-foreground">
                    Bikin kamu bersih dari cinta palsu dan mantan toksik. Laboratorium modern dan fasilitas lengkap untuk mendukung kegiatan belajar taruna/i.
                  </p>
                </motion.div>
                
                <motion.div 
                  className="bg-card p-8 rounded-xl shadow-md border border-border relative overflow-hidden"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.3 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary bg-opacity-5 rounded-bl-full"></div>
                  <Users size={48} className="text-primary mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Teknik Pendinginan Hati & Perasaan (TPHP)</h3>
                  <p className="text-muted-foreground">
                    Jurus anti baper, auto slow like es batu. Tenaga pengajar berpengalaman dan bersertifikat yang siap membimbing taruna/i menjadi generasi unggul.
                  </p>
                </motion.div>
                
                <motion.div 
                  className="bg-card p-8 rounded-xl shadow-md border border-border relative overflow-hidden"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.4 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary bg-opacity-5 rounded-bl-full"></div>
                  <BookOpen size={48} className="text-primary mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Multimedia Kelas Dewa (MKD)</h3>
                  <p className="text-muted-foreground">
                    Editan api naga & tulisan "Sakit Tapi Tak Berdarah" level profesional. Mengikuti perkembangan pendidikan nasional dengan kurikulum yang relevan dan berbasis kompetensi.
                  </p>
                </motion.div>
                
                <motion.div 
                  className="bg-card p-8 rounded-xl shadow-md border border-border relative overflow-hidden"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.5 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary bg-opacity-5 rounded-bl-full"></div>
                  <Book size={48} className="text-primary mb-4" />
                  <h3 className="text-2xl font-bold mb-2">Teknik Mesin Waktu dan Penyesalan (TMWP)</h3>
                  <p className="text-muted-foreground">
                    Khusus buat yang ingin kembali ke masa lalu, tapi cuma bisa nyesel. Program unggulan dengan metode pembelajaran interaktif.
                  </p>
                </motion.div>
                
                <motion.div 
                  className="bg-card p-8 rounded-xl shadow-md border border-border relative overflow-hidden"
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.6 }}
                  whileHover={{ y: -5, transition: { duration: 0.2 } }}
                >
                  <div className="absolute top-0 right-0 w-20 h-20 bg-primary bg-opacity-5 rounded-bl-full"></div>
                  <Code size={48} className="text-primary mb-4" />
                  <h3 className="text-2xl font-bold mb-2">PPLG (Pemrograman Perasaan Level Gacor)</h3>
                  <p className="text-muted-foreground">
                    Nge-code sambil ngatur perasaan? Di sini tempatnya, bosku! Program dengan kurikulum teknologi terbaru.
                  </p>
                </motion.div>
              </motion.div>
              
              <motion.div 
                className="flex justify-center"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 }}
              >
                <a 
                  href="https://docs.google.com/forms/d/e/1FAIpQLSdVMBbWa4QnQVGBOooETJVtNNTEGbHIQbMGmGoDLTNHK9dcaw/viewform" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-primary hover:bg-opacity-90 text-primary-foreground font-bold py-4 px-8 rounded-lg shadow-lg flex items-center gap-3 text-xl transition-all duration-300"
                >
                  <FileCheck className="h-6 w-6" />
                  Daftar Sekarang
                </a>
              </motion.div>
            </section>
            
            <section className="mb-16">
              <motion.div 
                className="flex flex-col items-center text-center mb-10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.7, duration: 0.5 }}
              >
                <h2 className="text-3xl font-bold text-primary mb-4">Jadwal Pendaftaran</h2>
                <p className="text-lg text-muted-foreground max-w-2xl mb-10">
                  Berikut adalah jadwal lengkap untuk proses penerimaan siswa baru tahun ajaran 2025/2026.
                </p>
                
                <div className="w-full max-w-3xl bg-card rounded-xl shadow-md overflow-hidden border border-border">
                  <table className="w-full">
                    <thead className="bg-primary bg-opacity-10">
                      <tr>
                        <th className="py-4 px-6 text-left font-semibold">Kegiatan</th>
                        <th className="py-4 px-6 text-left font-semibold">Tanggal</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-t border-border">
                        <td className="py-4 px-6">Pendaftaran Online</td>
                        <td className="py-4 px-6">18 Mei - 18 Juni 2025</td>
                      </tr>
                      <tr className="border-t border-border">
                        <td className="py-4 px-6">Seleksi Akademik</td>
                        <td className="py-4 px-6">28 - 30 Juni 2025</td>
                      </tr>
                      <tr className="border-t border-border">
                        <td className="py-4 px-6">Pengumuman Hasil Seleksi</td>
                        <td className="py-4 px-6">7 Juli 2025</td>
                      </tr>
                      <tr className="border-t border-border">
                        <td className="py-4 px-6">Daftar Ulang</td>
                        <td className="py-4 px-6">14 - 19 Juli 2025</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </motion.div>
            </section>
            
            {/* Removed the duplicate section */}
            
            {/* Registration Requirements Section */}
            <section className="mb-16">
              <motion.div 
                className="bg-card p-8 rounded-xl shadow-lg border border-border mb-10"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <div className="flex items-center mb-6 pb-4 border-b border-border">
                  <Award className="text-primary mr-3" size={28} />
                  <h2 className="text-2xl font-bold">Persyaratan Pendaftaran</h2>
                </div>
                
                <ul className="space-y-4 list-disc list-inside text-foreground">
                  <li className="pl-2">Fotokopi Ijazah SMP/MTs (dilegalisir) - 2 lembar</li>
                  <li className="pl-2">Fotokopi Akta Kelahiran - 2 lembar</li>
                  <li className="pl-2">Fotokopi Kartu Keluarga - 2 lembar</li>
                  <li className="pl-2">Pas foto berwarna ukuran 3x4 dengan latar belakang merah - 4 lembar</li>
                  <li className="pl-2">Surat Keterangan Sehat dari Puskesmas atau Rumah Sakit</li>
                  <li className="pl-2">Surat Keterangan Berkelakuan Baik dari sekolah asal</li>
                  <li className="pl-2">Bukti pembayaran biaya pendaftaran</li>
                </ul>
                
                <div className="mt-6 p-4 bg-primary bg-opacity-5 rounded-lg">
                  <p className="text-sm flex items-center gap-2">
                    <Rocket size={16} className="text-primary" />
                    <span>
                      <span className="font-bold">Catatan Penting:</span> Semua dokumen asli harus dibawa saat verifikasi data 
                      untuk pengecekan keaslian dokumen.
                    </span>
                  </p>
                </div>
              </motion.div>
              
              <motion.div
                className="flex justify-center mt-8"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <motion.a
                  href="https://wa.me/6285147844370"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 bg-[#25D366] text-white py-2 px-4 rounded-lg shadow-md group relative overflow-hidden text-sm"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <motion.div 
                    className="absolute inset-0 bg-white bg-opacity-20"
                    initial={{ x: '-100%' }}
                    whileHover={{ x: '100%' }}
                    transition={{ duration: 0.8 }}
                  />
                  <motion.div
                    className="flex items-center justify-center rounded-full bg-white p-1"
                    animate={{ rotate: [0, 10, -10, 10, 0] }}
                    transition={{ 
                      duration: 1.5, 
                      repeat: Infinity, 
                      repeatType: "loop", 
                      ease: "easeInOut",
                      repeatDelay: 2 
                    }}
                  >
                    <MessageCircle size={16} className="text-[#25D366]" />
                  </motion.div>
                  <span className="font-medium">Tanya Admin via WhatsApp</span>
                </motion.a>
              </motion.div>
            </section>
          </>
        )}
      </main>

      <footer className="w-full py-6 text-center text-sm text-muted-foreground border-t border-border mt-12">
        <p className="font-medium">© 2025 SMK Kapal Karam 723 Tanah Soetji</p>
        <p className="mt-1">Created by Tim IT Beng</p>
      </footer>
    </div>
  )
}
